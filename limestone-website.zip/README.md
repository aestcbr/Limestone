# Limestone Website

Website sederhana bertema batuan Limestone (batu kapur).

## Fitur
- Desain clean dan natural
- Informasi dasar tentang limestone
- Siap diupload ke GitHub

## Cara Menjalankan
Buka file index.html di browser.
